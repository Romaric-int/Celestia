@extends('templates.template')



@section('content')



@endsection
