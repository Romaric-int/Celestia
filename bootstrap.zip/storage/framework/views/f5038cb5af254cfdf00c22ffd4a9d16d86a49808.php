

<?php $__env->startSection('content'); ?>





    <div class="quizz quizz"  id="quiz">
      <h1>Quizz </h1>
      <h2><img src="/img/laika/tete_contente.png" width="70px" alt=""><span id="question" ></span></h2>
      <h3 id="score"></h3>
      <a href="/game/1" id="revoir_video">Revoir la vidéo</a>

      <div class="choices">
        <?php for($w = 0; $w < 4; $w++): ?>
        <button  class="btn_choice guess<?php echo e($w); ?>">
          <p  class="choice<?php echo e($w); ?>"></p>
        </button>
        <?php endfor; ?>

      </div>


    </div>


    <script src="/js/quiz.js"></script>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Celestia\resources\views/firstcontroller/quiz.blade.php ENDPATH**/ ?>