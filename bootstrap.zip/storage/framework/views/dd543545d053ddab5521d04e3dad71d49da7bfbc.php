

<?php $__env->startSection('content'); ?>
<section class="page-video">

  <h1 class="titre-video"><?php echo e($video->name); ?></h1>
  <p>Préchauffez le four à 200°C (Th 6-7). Décongelez les épinards, à feu doux, dans une casserole, puis enlevez l’eau résiduelle (n’hésitez pas à appuyer pour la faire sortir!). Hachez-les grossièrement (je le fais au ciseau).</p>
  <object width="1100" height="650" data="<?php echo e($video->urlVideo); ?>"></object>


<?php if(Auth::check()): ?>
  <?php if(Auth::user()->step_story >= $video->id): ?>
  <a class="btn btn_diy" href="/game">J'ai compris, je continue l'aventure !</a>

  <?php else: ?>
  <a class="btn btn_diy" href="/next-step">J'ai compris, je continue l'aventure !</a>
  <?php endif; ?>

<?php else: ?>

  <a class="btn btn_diy" href="/game">J'ai compris, je continue l'aventure !</a>

<?php endif; ?>

</section>
<?php $__env->stopSection(); ?>

<style media="screen">
  body {
    background-image: url('/img/video/fond_video.svg');
    color: white;
  }

  .btn_diy{

    margin-bottom: 4rem;
  }

</style>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Celestia\resources\views/firstcontroller/video.blade.php ENDPATH**/ ?>