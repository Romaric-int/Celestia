


<?php $__env->startSection('content'); ?>
<section class="prep_diy">

  
  <h1><?php echo e($recette->name); ?></h1>
  <img src="<?php echo e($recette->url); ?>" alt="">

  <div class="trait_diy">

  </div>

  <div class="expli_diy">


    <ul class="ingre">
      <h1>Matériel</h1>
      <?php $__currentLoopData = $tab_prep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <li><?php echo e($val); ?></li>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <ul class="preparation">
      <h1>Préparation</h1>
    <?php $__currentLoopData = $tab_diy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


      <li class="<?php echo e($key); ?>"><?php echo e($val); ?></li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>

</section>

<?php $__env->stopSection(); ?>


<style media="screen">
  body {
    background-image: url("/img/diy/fond_diy.svg");
  }



</style>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Celestia\resources\views/firstcontroller/diy.blade.php ENDPATH**/ ?>