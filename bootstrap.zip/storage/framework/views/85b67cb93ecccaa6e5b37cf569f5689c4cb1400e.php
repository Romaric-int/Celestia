

<?php $__env->startSection('content'); ?>

  <div class="flex-planet">

<?php if(Auth::check()): ?>

  <div class="diego_help">
    <img src="/img/game/diego_help.svg" alt="diego">
    <h1>A l’aide!!!</h1>
  </div>

<?php for($i=1; $i < count($planete); $i++): ?>






    <div class="quizz quizz"  id="quiz<?php echo e($i); ?>">
      <h1>Quizz </h1>
      <h2><img src="/img/laika/tete_contente.png" width="70px" alt=""><span id="question<?php echo e($i); ?>" ></span></h2>
      <h3 id="score"></h3>
      <a href="/game/1" id="revoir_video">Revoir la vidéo</a>

      <div class="choices">
        <?php for($w = 0; $w < 4; $w++): ?>
        <button  class="btn_choice guess<?php echo e($w); ?>">
          <p  class="choice<?php echo e($w); ?>"></p>
        </button>
        <?php endfor; ?>

      </div>


    </div>



  <?php if(Auth::user()->step_story == $i && Auth::user()->step_vid != $i): ?>

    <style media="screen">
      #quiz<?php echo e($i); ?> {
        visibility: visible;
      }

      .storyText{
        visibility: hidden;
      }
    </style>

  <?php endif; ?>
<?php endfor; ?>
  <script src="/js/quiz.js"></script>


<?php $__currentLoopData = $planete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="planete planete<?php echo e($p->id); ?>">
      <a href="/game/<?php echo e($p->id); ?>"><img src="<?php echo e($p->planete); ?>" class="img-planete img-planete<?php echo e($p->id); ?>"alt="planete<?php echo e($p->id); ?>"></a>
      <img class="num-planete num-planete<?php echo e($p->id); ?>" src="<?php echo e($p->numImg); ?>" alt="numero<?php echo e($p->id); ?>">
      <div class="story-text story-text<?php echo e($p->id); ?>">
        <p class="text-laika text-laika<?php echo e($p->id); ?>"></p>
      </div>
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--quizz -->



<!-- -->

<?php $__currentLoopData = $planete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if(Auth::user()->step_vid == $p->id): ?>
  <div class="storyText"> <img src="/img/laika/tete_contente.png" width='50%'alt=""> <p><?php echo e($p->storyText); ?></p></div>
<?php elseif(Auth::user()->step_vid == 0): ?>
  <p class="storyText"> Intro </p>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php


$tab = [2,3,4,5,6];

for ($i=0; $i < 5; $i++) {
  if (Auth::user()->step_vid == $i){
    for ($j=Auth::user()->step_vid; $j < count($tab); $j++){
      echo "<style media='screen'>
        .planete".$tab[$j]."{
        filter: blur(4px);
        cursor: default;
        pointer-events: none;

      }</style>";
    };

    $e = $i+1;
    echo "<style  media='screen'>
    .text-laika".$e."{
      visibility: visible;

    }</style>
    ";
    $step = Auth::user()->step_vid;

    for ($i=1; $i < $step+2; $i++) {
    echo "<style  media='screen'>
    .num-planete".$i." {

    filter: grayscale(0%);
  }
  .img-planete".$i."{
    filter: grayscale(0%);
  }</style>";
  };




  };
};




 ?>

<?php else: ?>


<?php $__currentLoopData = $planete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="planete planete<?php echo e($p->id); ?>">
      <a href="/game/<?php echo e($p->id); ?>"><img src="<?php echo e($p->planete); ?>" alt="planete<?php echo e($p->id); ?>"></a>
      <img class="num-planete" src="<?php echo e($p->numImg); ?>" alt="numero<?php echo e($p->id); ?>">
      <div class="story-text<?php echo e($p->id); ?>">

      </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <p class="storyText">Connectez-vous profiter du mode histoire !</p>

  <style media="screen">
  .num-planete{
    filter: grayscale(0%);
  }

  .planete6 {
    display: none;
  }
  </style>
<?php endif; ?>

  </div>




<?php $__env->stopSection(); ?>

<style media="screen">
  .game {
    background-color: #F28DD1 !important;
  }
  body {
    background-image: url('/img/game/fond_game.svg');
    background-position: left;
    background-repeat: no-repeat;
    background-size: cover;
    overflow-y: hidden;
    height: 100vh;

  }

  .page-game {
    width: 4000px;
    height: 10%;


  }
  .main-header {
    position: fixed !important;
  }

  .logo-header {
    margin-right: 200px;
    margin-left: 100px;
  }

  .footer{
    display: none !important;
  }


</style>



<script type="text/javascript">
  addEventListener("load", function(){
  document.body.addEventListener("wheel", function(e){
  e.preventDefault();
  document.body.scrollLeft+=e.deltaY<0 ? -400 : 400
  }, false);}, false);
</script>

<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Celestia\resources\views/firstcontroller/game.blade.php ENDPATH**/ ?>